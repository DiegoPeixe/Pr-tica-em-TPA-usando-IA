<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TeacherController;
Route::get('/', function () {
    return view('welcome');
});
Route::get('/', [TeacherController::class, 'index'])->name('teachers.index'); // Rota para listar usuários
Route::get('/teachers/create', [TeacherController::class, 'create'])->name('teachers.create'); // Rota para criar usuário
Route::post('/teachers', [TeacherController::class, 'store'])->name('teachers.store'); // Rota para armazenar usuário
Route::get('/teachers/{id}/edit', [TeacherController::class, 'edit'])->name('teachers.edit'); // Rota para editar usuário
Route::put('/teachers/{id}', [TeacherController::class, 'update'])->name('teachers.update'); // Rota para atualizar usuário
Route::delete('/teachers/{id}', [TeacherController::class, 'destroy'])->name('teachers.destroy'); // Rota para excluir usuário
