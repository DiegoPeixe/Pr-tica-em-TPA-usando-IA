<?php


namespace App\Http\Controllers;


use App\Models\Teacher;
use Illuminate\Http\Request;


class TeacherController extends Controller
{
    public function index()
    {
        $teachers = Teacher::all(); // Busca todos os professores do banco de dados
        return view('teachers.index', compact('teachers')); // Retorna a view com os dados dos professores
    }
    public function create()
    {
        return view('teachers.create'); // Retorna a view para criar um novo
    }


    public function store(Request $request)
    {
        // Valida os dados recebidos
        $request->validate([
            'teacher' => 'required|unique:teachers',
            'city' => 'required',
        ]);
        // Cria um novo com os dados validados
        Teacher::create([
            'teacher' => $request->teacher,
            'city' => $request->city,
        ]);




        return redirect()->route('teachers.index')->with('success', 'Professor criado com sucesso.');
    }
    public function edit($id)
    {
        $teacher = Teacher::findOrFail($id); // Busca o professor pelo ID ou retorna 404 se não encontrado
        return view('teachers.edit', compact('teacher')); // Retorna a view de edição
    }


    public function update(Request $request, $id)
    {
        // Valida os dados recebidos
        $request->validate([
            'teacher' => 'required|unique:teachers,teacher,' . $id,
            'city' => 'required',
        ]);
        // Busca o professor pelo ID
        $teacher = Teacher::findOrFail($id);
        // Atualiza os dados
        $teacher->update([
            'teacher' => $request->teacher,
            'city' => $request->city,
        ]);
        return redirect()->route('teachers.index')->with('success', 'Professor atualizado com sucesso.');
    }


    public function destroy($id)
    {
        Teacher::findOrFail($id)->delete(); // Busca e o exclui
        return redirect()->route('teachers.index')->with('success', 'Professor excluído com sucesso.');
    }
}
