@extends('layouts.app') <!-- Extende o layout base 'app.blade.php' -->


@section('content') <!-- Define a seção 'content' que será inserida no layout base -->
<h1>Professores</h1>
<a href="{{ route('teachers.create') }}" class="btn btn-primary">Adicionar Professor</a>




@if (session('success')) <!-- Verifica se existe uma mensagem de sucesso na sessão -->
    <div class="alert alert-success mt-3">
        {{ session('success') }} <!-- Exibe a mensagem de sucesso -->
    </div>
@endif




<table class="table mt-3">
    <thead>
        <tr>
            <th>ID</th>
            <th>Professor</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($teachers as $teacher) <!-- Itera sobre a lista de usuários -->
        <tr>
            <td>{{ $teacher->id }}</td> <!-- Exibe o ID do usuário -->
            <td>{{ $teacher->teacher }}</td> <!-- Exibe o nome do usuário -->
            <td>
                <a href="{{ route('teachers.edit', $teacher->id) }}" class="btn btn-warning">Editar</a> <!-- Link para editar -->
                <form action="{{ route('teachers.destroy', $teacher->id) }}" method="POST" style="display:inline;"> <!-- Formulário para excluir -->
                    @csrf <!-- Token de proteção contra CSRF -->
                    @method('DELETE') <!-- Método para exclui -->
                    <button type="submit" class="btn btn-danger">Excluir</button> <!-- Botão para excluir -->
                </form>
            </td>
        </tr>
        @endforeach <!-- Fim da iteração -->
    </tbody>
</table>
@endsection <!-- Fim da seção 'content' -->
